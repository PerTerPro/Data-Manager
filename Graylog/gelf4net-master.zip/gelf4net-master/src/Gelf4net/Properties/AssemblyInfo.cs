﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("gelf4net")]
[assembly: AssemblyProduct("gelf4net")]
[assembly: Guid("C92B1448-EF37-432B-B9C2-C843831B3CFA")]