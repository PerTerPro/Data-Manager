using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("gelf4net")]
[assembly: AssemblyFileVersion("3.0.0.1")]
[assembly: AssemblyVersion("3.0.0.1")]
[assembly: AssemblyCopyright("Copyright �  2016")]
[assembly: ComVisible(false)]
